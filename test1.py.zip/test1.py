#test1.py
import requests
import os

URL = 'http://66.175.212.157:8080/classify'
file_name = input()
myfiles = {'imagefile': open(os.getcwd() + "/" + file_name ,'rb')}
print((requests.post(url = URL, files = myfiles)).text)