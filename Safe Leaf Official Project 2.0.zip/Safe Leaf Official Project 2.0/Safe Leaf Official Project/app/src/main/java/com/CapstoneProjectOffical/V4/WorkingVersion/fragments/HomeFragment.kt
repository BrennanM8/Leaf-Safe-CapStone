package com.CapstoneProjectOffical.V4.WorkingVersion.fragments

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.CapstoneProjectOffical.V4.WorkingVersion.R
import kotlinx.android.synthetic.main.fragment_home.*

class HomeFragment : Fragment() { //changed from fragment
    companion object{
        val IMAGE_REQUEST_CODE = 100

    }
    private lateinit var button: Button
    private val cameraRequest = 1888
    lateinit var imageView: ImageView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?

    ): View? {




        super.onCreate(savedInstanceState)

        // Inflate the layout for this fragment
        val myview: View = inflater.inflate(R.layout.fragment_home, container, false)
        val button = myview.findViewById<Button>(R.id.plantSelectImage)
        val buttonResults = myview.findViewById<Button>(R.id.buttonResults)



        button.setOnClickListener {
            pickImageGallery()
            Toast.makeText(myview.context, "HI", Toast.LENGTH_SHORT).show()
        }


        buttonResults.setOnClickListener{
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("http://www.gardenanswers.com/weeds/yes-it-is-poison-ivy/"))
            startActivity(i)
        }

        ///Take a photo Matt's Part ///

        if (ContextCompat.checkSelfPermission(myview.context, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_DENIED)
            this.activity?.let { ActivityCompat.requestPermissions(it, arrayOf(Manifest.permission.CAMERA), cameraRequest) }

        imageView = myview.findViewById<View>(R.id.imageView) as ImageView
        val photoButton: Button = myview.findViewById<Button>(R.id.button)
        photoButton.setOnClickListener {
            val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            startActivityForResult(cameraIntent, cameraRequest)
        }


        return myview

    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == cameraRequest) {
            val photo: Bitmap = data?.extras?.get("data") as Bitmap
            imageView.setImageBitmap(photo)
        }
        if(requestCode == IMAGE_REQUEST_CODE && resultCode == AppCompatActivity.RESULT_OK) {
            imageView.setImageURI(data?.data)
        }
    }

    private fun pickImageGallery(){
        val intent = Intent(Intent.ACTION_PICK)
        intent.type= "image/*"
        startActivityForResult(intent, IMAGE_REQUEST_CODE)
    }
/*
    companion object{
        val IMAGE_REQUEST_CODE = 100

    }
    private lateinit var button: Button
    private val cameraRequest = 1888
    lateinit var imageView: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        supportActionBar?.hide()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_home)
        title = "KotlinApp"
        button = findViewById(R.id.plantSelectImage)

        button.setOnClickListener{
            pickImageGallery()
            /*Press Alt + Enter*/
        }

        if (ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_DENIED)
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), cameraRequest)
        imageView = findViewById(R.id.imageView)
        val photoButton: Button = findViewById(R.id.button)
        photoButton.setOnClickListener {
            val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            startActivityForResult(cameraIntent, cameraRequest)
        }

    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == cameraRequest) {
            val photo: Bitmap = data?.extras?.get("data") as Bitmap
            imageView.setImageBitmap(photo)
        }
        if(requestCode == IMAGE_REQUEST_CODE && resultCode == AppCompatActivity.RESULT_OK) {
            imageView.setImageURI(data?.data)
        }
    }

    private fun pickImageGallery(){
        val intent = Intent(Intent.ACTION_PICK)
        intent.type= "image/*"
        startActivityForResult(intent, IMAGE_REQUEST_CODE)
    }
    */
 */



}