public class Response {

    private boolean ivy;
    private double weightCertain;
    public Response (String resp) {
        String[] data = resp.split(" ");
        this.ivy = (data[0].charAt(2) == 'T');
        if (!this.ivy) {
            weightCertain = Double.parseDouble(data[2].substring(12, data[2].length()-1));
        } else {
            weightCertain = Double.parseDouble(data[3].substring(0, data[3].indexOf("]")));
        }
    }

    public double getWeightCertain() {
        return this.weightCertain;
    }

    public double getWeightUncertain() {
        return 1.0 - this.weightCertain;
    }

    public boolean getIvy() {
        return this.ivy;
    }
}
