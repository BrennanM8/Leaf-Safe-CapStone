import java.io.File;

public class Test {
    public static void main(String [] args) {
        try {
            String requestURL = "http://66.175.212.157:8080/classify";
            String file_path = "/Images/";
            String currentPath = new java.io.File(".").getCanonicalPath();
            for (int i = 0; i < 20; i++) {
                MultipartUtilityV2 multipart = new MultipartUtilityV2(requestURL);
                multipart.addFilePart("imagefile", new File(currentPath + file_path + "poison-ivy" + i + ".jpeg"));
                String response = multipart.finish(); // response from server.
                System.out.println(response);
                Response rsp = new Response(response);
                if (rsp.getIvy()) {
                    System.out.println("There is a " + (int)(rsp.getWeightCertain() * 100) + "% certainty this is poison ivy");
                } else {
                    System.out.println("There is a " + (int)(rsp.getWeightCertain() * 100) + "% certainty this is not poison ivy");
                }
                multipart = new MultipartUtilityV2(requestURL);
                multipart.addFilePart("imagefile", new File(currentPath + file_path + "box-elder" + i + ".jpeg"));
                response = multipart.finish(); // response from server.
                System.out.println(response);
                rsp = new Response(response);
                if (rsp.getIvy()) {
                    System.out.println("There is a " + (int)(rsp.getWeightCertain() * 100) + "% certainty this is poison ivy");
                } else {
                    System.out.println("There is a " + (int)(rsp.getWeightCertain() * 100) + "% certainty this is not poison ivy");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
